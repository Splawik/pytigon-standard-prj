import types
import wx
import time
import wx.lib.agw.ribbon as RB


WXK_MAP = {}

START_MACRO = """
import xmlrpc.client
import time
from pytigon_lib.schtools.winauto import Window

with xmlrpc.client.ServerProxy("http://localhost:5000/") as proxy:
"""


def map_keys():
    global WXK_MAP
    tab = dir(wx)
    for item in tab:
        if item.startswith("WXK_"):
            value = getattr(wx, item)
            key = item[4:]
            WXK_MAP[value] = key


class FilterObj(wx.EventFilter):
    def __init__(self):
        super().__init__()
        wx.EvtHandler.AddFilter(self)
        self.evt_type = None
        self.keys_buf = ""
        self.action_tab = []

    def __del__(self):
        # Wyrejestrowanie filtra podczas niszczenia obiektu
        self.flush_buf()
        wx.EvtHandler.RemoveFilter(self)

    def _selector(self, obj):
        parent = None if not obj else obj.GetParent()
        gparent = None if not parent else parent.GetParent()
        selector = ""
        if gparent:
            gparent_name = gparent.GetName()
            gparent_type = type(gparent).__name__
            selector = f"{gparent_name}.{gparent_type}>"
        if parent:
            parent_name = parent.GetName()
            parent_type = type(parent).__name__
            selector += f"{parent_name}.{parent_type}>"
        if obj:
            obj_name = obj.GetName() if obj else "Unknown Object"
            obj_type = type(obj).__name__
            selector += f"{obj_name}.{obj_type}"
        else:
            selector = ""
        return selector

    def output_action_tab(self, out_stream):
        out_stream.write(START_MACRO)
        for item in self.action_tab:
            if item[0] == "KEY":
                out_stream.write(f'    proxy.key("""{item[1]}""")')
            elif item[0] == "MOUSE":
                if item[3]:
                    out_stream.write(
                        f"    Window(proxy, '{item[2]}').clickbarbutton('{item[3]}')"
                    )
                else:
                    out_stream.write(
                        f"    Window(proxy, '{item[2]}').setpointer().click()"
                    )
            elif item[0] == "FOCUS":
                out_stream.write(f"    Window(proxy, '{item[1]}').setfocus()")
            out_stream.write("\n")

    def flush_buf(self):
        self.action_tab.append(("KEY", self.keys_buf))
        self.keys_buf = ""

    def FilterEvent(self, event):
        # Retrieve the event type identifier
        global WXK_MAP

        evt_type = event.GetEventType()

        # 1. Capture Key Presses (Keyboard Input)
        if evt_type in (wx.EVT_KEY_DOWN.typeId, wx.EVT_KEY_UP.typeId):
            # Safely cast or query properties from the event
            key_code = event.GetKeyCode()
            obj = event.GetEventObject()
            obj_name = obj.GetName() if obj else "Unknown Object"

            if evt_type == wx.EVT_KEY_DOWN.typeId:
                t = "_"
            else:
                t = "^"

            if key_code in WXK_MAP:
                code = WXK_MAP[key_code]
                s = f"[{t}{code}]"
                #print(
                #    f"[KEYBOARD] Key '[{t}{code}]' (code: {key_code}) pressed in widget: '{obj_name}'"
                #)
            else:
                c = chr(key_code)
                s = f"{c}"
                if t == "^":
                    pass
                    #print(
                    #    f"[KEYBOARD] Key '{c}' (code: {key_code}) pressed in widget: '{obj_name}'"
                    #)
                else:
                    s = ""
            if self.evt_type == "KEY":
                self.keys_buf += s
            else:
                self.keys_buf = s
            self.evt_type = "KEY"

        # 2. Capture Mouse Clicks (Left, Right, or Middle click)
        elif evt_type in (
            wx.EVT_LEFT_DOWN.typeId,
            wx.EVT_RIGHT_DOWN.typeId,
        ):
            self.evt_type = "MOUSE"
            if self.keys_buf:
                self.flush_buf()
            pos = event.GetPosition()
            obj = event.GetEventObject()

            obj_name = obj.GetName() if obj else "Unknown Object"
            obj_type = type(obj).__name__

            # Determine which button was pressed
            if evt_type == wx.EVT_LEFT_DOWN.typeId:
                btn = "Left"
            else:
                btn = "Right"

            #print(
            #    f"[MOUSE] Clicked {btn} button at position {pos} in object: '{obj_name}.{obj_type}'"
            #)

            if (
                btn == "Left"
                and f"{obj_name}.{obj_type}" == "RibbonControl.RibbonButtonBar"
            ):
                i = 0
                pos2 = obj.GetScreenPosition()
                for b in obj._layouts[0].buttons:
                    pos3 = b.position
                    if pos.x < pos3.x and i > 0:
                        btn_label = obj._buttons[i - 1].label
                        self.action_tab.append(
                            ["MOUSE", btn, self._selector(obj), btn_label]
                        )
                        if btn_label == "Exit":
                            with open("/tmp/log.py", "wt") as f:
                                self.output_action_tab(f)
                        break
                    i += 1
            else:
                self.action_tab.append(["MOUSE", btn, self._selector(obj), ""])

        # 3. Capture Focus Changes (SetFocus Event)
        elif evt_type == wx.EVT_SET_FOCUS.typeId:
            self.evt_type = "FOCUS"
            if self.keys_buf:
                self.flush_buf()
            obj = event.GetEventObject()
            obj_name = obj.GetName() if obj else "Unknown Object"
            obj_type = type(obj).__name__
            #print(f"[FOCUS] selector: '{obj_name}.{obj_type}'")
            self.action_tab.append(["FOCUS", self._selector(obj)])

        return wx.EventFilter.Event_Skip


def find_all_windows_by_name(name, parent=None):
    """
    Recursively finds and returns a list of all windows with the given name.
    If parent is None, the search starts from the application's TopLevelWindows.
    """
    found_windows = []

    # If no parent is provided, start with top-level windows (e.g., wx.Frame, wx.Dialog)
    if parent is None:
        for tlw in wx.GetTopLevelWindows():
            found_windows.extend(find_all_windows_by_name(name, tlw))
        return found_windows

    # Check the current window
    if parent.GetName() == name:
        found_windows.append(parent)

    # Recursively iterate through all children of the current window
    for child in parent.GetChildren():
        found_windows.extend(find_all_windows_by_name(name, child))

    return found_windows


def decode_selector(selector):
    if ":" in selector:
        x = selector.rsplit(":", 1)
        label = x[1]
        buf = x[0]
    else:
        label = ""
        buf = selector
    if "." in buf:
        x2 = buf.rsplit(".", 1)
        class_name = x2[1]
        name = x2[0]
    else:
        class_name = ""
        name = buf

    return name, class_name, label


def check_attrs(win, attrs):
    print("check: ", attrs)
    if not attrs[0] or win.GetName() == attrs[0]:
        if not attrs[1] or type(win).__name__ == attrs[1]:
            if not attrs[2] or win.GetLabel() == attrs[2]:
                print("check OK: ", attrs)
                return True
    print("NOT OK: ", attrs, win.GetName(), type(win).__name__, win.GetLabel())
    return False


def find_window(selector, start_window=None) -> wx.Window or None:
    """
    Efficiently finds a window/control with a specific label and class name
    by leveraging the built-in wx.FindWindowByLabel function.
    """

    tab = []
    if ">" in selector:
        x = selector.split(">")
        print("x: ", x)
        for item in x[::-1]:
            tab.append(decode_selector(item.strip()))
    else:
        tab.append(decode_selector(selector.strip()))

    tt = find_all_windows_by_name(tab[0][0])
    print("TT: ", tt)

    for window in find_all_windows_by_name(tab[0][0]):
        # Search for a window with the given label.
        # Passing 'start_window' allows wxPython to continue searching
        # for the "next" match if the previous one didn't meet the class criteria.

        if not window:
            return None

        print("O1")

        # Check if the class name matches
        if check_attrs(window, tab[0]):
            print("O2")
            check = True
            parent = window
            for item in tab[1:]:
                parent = parent.GetParent()
                if not parent:
                    check = False
                    print("Not parent")
                    break
                print("O3: ", parent, item)
                check = check_attrs(parent, item)
                if not check:
                    break
            if check:
                return window
    return None


def move_cursor(x, y, dt=0.01):
    start_pos = wx.GetMousePosition()
    print(start_pos.x, start_pos.y, x, y)
    delta = int((((x - start_pos.x) ** 2) + ((y - start_pos.y) ** 2)) ** 0.5 / 40)
    print(delta)
    sim = wx.UIActionSimulator()
    for i in range(0, delta):
        x2 = start_pos.x + int(i * (x - start_pos.x) / delta)
        y2 = start_pos.y + int(i * (y - start_pos.y) / delta)
        # print(x2, y2)
        sim.MouseMove(x2, y2)
        time.sleep(dt)
    sim.MouseMove(x, y)


def init_plugin(
    app,
    mainframe,
    desktop,
    mgr,
    menubar,
    toolbar,
    accel,
):
    map_keys()
    app.event_filter = FilterObj()

    def xmlrpc_test(self):
        return "OK"

    app.xmlrpc_test = types.MethodType(xmlrpc_test, app)

    def xmlrpc_findwindow(self, selector, win_id=0):
        if int(win_id) != 0:
            parent = wx.FindWindowById(int(win_id))
        else:
            parent = None
        win = find_window(selector, parent)
        if win:
            return win.GetId()
        else:
            return 0

    app.xmlrpc_findwindow = types.MethodType(xmlrpc_findwindow, app)

    def xmlrpc_gettoolbarbutton(self, win_id, label):
        win = wx.FindWindowById(win_id)
        if win:
            i = 0
            for btn in win._buttons:
                if btn.label == label:
                    pos = win._layouts[0].buttons[i].position
                    pos2 = win.GetScreenPosition()
                    return (pos.x + pos2.x, pos.y + pos2.y)
                i += 1
        return 0

    app.xmlrpc_gettoolbarbutton = types.MethodType(xmlrpc_gettoolbarbutton, app)

    def xmlrpc_clickbarbutton(self, win_id, label):
        win = wx.FindWindowById(win_id)
        if win:
            i = 0
            for btn in win._buttons:
                if btn.label == label:
                    button_id = btn.id
                    event_type = RB.EVT_RIBBONBUTTONBAR_CLICKED.typeId
                    event = RB.RibbonButtonBarEvent(event_type, button_id, btn)
                    event.SetEventObject(win)
                    win.GetEventHandler().ProcessEvent(event)
                    return 1
                i += 1
        return 0

    app.xmlrpc_clickbarbutton = types.MethodType(xmlrpc_clickbarbutton, app)

    def xmlrpc_setpointer(self, win_id, pos=None):
        win = wx.FindWindowById(win_id)
        if win:
            if pos:
                # win.WarpPointer(pos[0], pos[1])
                move_cursor(pos[0], pos[1])
            else:
                pos = win.GetScreenPosition()
                w, h = win.GetSize()
                x = w // 2
                y = h // 2
                move_cursor(pos.x + x, pos.y + y)
                # win.WarpPointer(x, y)
            return 1
        return 0

    app.xmlrpc_setpointer = types.MethodType(xmlrpc_setpointer, app)

    def xmlrpc_click(self, win_id):
        win = wx.FindWindowById(win_id)
        if win:
            event = wx.CommandEvent(wx.wxEVT_BUTTON, win.GetId())
            event.SetEventObject(win)
            win.GetEventHandler().ProcessEvent(event)
            return 1
        return 0

    app.xmlrpc_click = types.MethodType(xmlrpc_click, app)

    def xmlrpc_mouseclick(self):
        sim = wx.UIActionSimulator()
        sim.MouseClick(wx.MOUSE_BTN_LEFT)
        return 1

    app.xmlrpc_mouseclick = types.MethodType(xmlrpc_mouseclick, app)

    def xmlrpc_setfocus(self, win_id):
        win = wx.FindWindowById(win_id)
        if win:
            win.SetFocus()
            return 1
        return 0

    app.xmlrpc_setfocus = types.MethodType(xmlrpc_setfocus, app)

    def xmlrpc_setvalue(self, win_id, value):
        win = wx.FindWindowById(win_id)
        if win:
            win.SetValue(value)
            return 1
        return 0

    app.xmlrpc_setvalue = types.MethodType(xmlrpc_setvalue, app)

    def xmlrpc_key(win_id, value):
        sim = wx.UIActionSimulator()
        in_code = False
        code = ""
        for c in value:
            if in_code:
                if c == "]":
                    if code == "(":
                        x = ord("[")
                        sim.KeyDown(x)
                        sim.KeyUp(x)
                    else:
                        if code[0] == "_":
                            x = eval("wx.WXK_" + code[1:])
                            sim.KeyDown(x)
                        elif code[0] == "^":
                            x = eval("wx.WXK_" + code[1:])
                            sim.KeyUp(x)
                        else:
                            x = eval("wx.WXK_" + code)
                            sim.KeyDown(x)
                            sim.KeyUp(x)
                    code = ""
                    in_code = False
                else:
                    code += c
            else:
                if c == "[":
                    in_code = True
                    code = ""
                    continue
                else:
                    x = ord(c)
                    sim.KeyDown(x)
                    sim.KeyUp(x)
        return 1

    app.xmlrpc_key = types.MethodType(xmlrpc_key, app)

